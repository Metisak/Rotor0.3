using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallConfig : MonoBehaviour
{
    [SerializeField]
    float force;
    float MoveSpeed;
    Rigidbody2D Ball;
    
    
    
    // Start is called before the first frame update
    void Start()
    {

        Ball = this.GetComponent<Rigidbody2D>();
        MoveSpeed = 5f;
    }

    // Update is called once per frame
    void Update()
    {


        if (Input.GetKey(KeyCode.LeftArrow))
        {
            Ball.transform.Translate(Vector2.left * MoveSpeed * Time.deltaTime);
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            Ball.transform.Translate(Vector2.right * MoveSpeed * Time.deltaTime);
        }



        if (Input.GetKeyDown(KeyCode.Space))
         { 
        
        Ball.AddForce (new Vector2(0,1) * force,  ForceMode2D.Impulse);
        
        }
        







    }
}
